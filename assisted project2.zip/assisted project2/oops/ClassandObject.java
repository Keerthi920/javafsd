package first;


	public class ClassandObject 
	{  
	    String name; 
	    String breed; 
	    int age; 
	    String color;
		private String address; 
	    public ClassandObject(String name, int age, String address) 
	    { 
	        this.name = name; 
	        this.age = age; 
	        this.address = address; 
	    } 
	    public String getName() 
	    { 
	        return name; 
	    } 
	    
	    public int getAge() 
	    { 
	        return age; 
	    } 
	    private String getaddress() 
	    { 
	        return address; 
	    } 
	    @Override
	    public String toString() 
	    { 
	        return("Hi my name is "+ this.getName()+ ".\nMy age and address are "  + this.getAge()+ ", and " + this.getaddress() + "."); 
	    } 
	    public static void main(String[] args) 
	    { 
	        ClassandObject scott = new ClassandObject("Keertana", 22, "Rajahmundry"); 
	        System.out.println(scott.toString()); 
	    } 
	}


//}
